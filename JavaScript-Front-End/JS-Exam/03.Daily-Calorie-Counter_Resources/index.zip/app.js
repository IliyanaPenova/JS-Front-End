document.addEventListener('DOMContentLoaded', () => {
    const apiUrl = 'http://localhost:3030/jsonstore/tasks/';
    const listContainer = document.getElementById('list');
    const form = document.querySelector('#form form');
    const addMealBtn = document.getElementById('add-meal');
    const editMealBtn = document.getElementById('edit-meal');
    const loadMealsBtn = document.getElementById('load-meals');

    // Function to load meals
    const loadMeals = async () => {
        try {
            const response = await fetch(apiUrl);

            if (!response.ok) {
                throw new Error(`Failed to load meals: ${response.statusText}`);
            }

            const data = await response.json();

            // Clear existing list
            listContainer.innerHTML = '';

            // Populate the list
            for (const mealId in data) {
                const meal = data[mealId];
                const listItem = createListItem(meal, mealId);
                listContainer.appendChild(listItem);
            }
        } catch (error) {
            console.error(error);
        }
    };

    // Function to create list item
    const createListItem = (meal, mealId) => {
        const listItem = document.createElement('div');
        listItem.classList.add('meal');
        listItem.innerHTML = `
            <h2>${meal.food}</h2>
            <h3>${meal.time}</h3>
            <h3>${meal.calories}</h3>
            <div class="meal-buttons">
                <button class="change-meal" data-meal-id="${mealId}">Change</button>
                <button class="delete-meal" data-meal-id="${mealId}">Delete</button>
            </div>
        `;

        return listItem;
    };

    // Event listener for [Load Meals] button
    loadMealsBtn.addEventListener('click', loadMeals);

    // Event listener for [Add Meal] button
    addMealBtn.addEventListener('click', async () => {
        try {
            const food = document.getElementById('food').value;
            const time = document.getElementById('time').value;
            const calories = document.getElementById('calories').value;

            // Send POST request to add a new meal
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ food, time, calories }),
            });

            if (!response.ok) {
                throw new Error(`Failed to add meal: ${response.statusText}`);
            }

            // Fetch meals after successful creation
            await loadMeals();
            // Clear input fields
            form.reset();
        } catch (error) {
            console.error('Error adding meal:', error);
        }
    });

    // Event listener for [Edit Meal] button
    editMealBtn.addEventListener('click', async () => {
        try {
            const mealId = form.dataset.editMealId;
            const food = document.getElementById('food').value;
            const time = document.getElementById('time').value;
            const calories = document.getElementById('calories').value;

            // Send PUT request to edit a meal
            const response = await fetch(apiUrl + mealId, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ food, time, calories }),
            });

            if (!response.ok) {
                throw new Error(`Failed to edit meal: ${response.statusText}`);
            }

            // Fetch meals after successful edit
            await loadMeals();
            // Deactivate [Edit Meal] button, activate [Add Meal] button
            editMealBtn.disabled = true;
            addMealBtn.disabled = false;
            // Clear input fields
            form.reset();
        } catch (error) {
            console.error('Error editing meal:', error);
        }
    });

    // Function to handle [Change] and [Delete] button clicks
    listContainer.addEventListener('click', async (event) => {
        const target = event.target;

        if (target.classList.contains('change-meal')) {
            const mealId = target.dataset.mealId;
            handleEditClick(mealId);
        } else if (target.classList.contains('delete-meal')) {
            const mealId = target.dataset.mealId;
            await handleDeleteClick(mealId);
        }
    });

    // Function to handle [Change] button click (edit meal)
    const handleEditClick = (mealId) => {
        const mealDetails = getMealDetailsById(mealId);

        // Populate the input fields with the meal information
        document.getElementById('food').value = mealDetails.food;
        document.getElementById('time').value = mealDetails.time;
        document.getElementById('calories').value = mealDetails.calories;

        // Activate [Edit Meal] button, deactivate [Add Meal] button
        editMealBtn.disabled = false;
        addMealBtn.disabled = true;

        // Set the meal ID as a data attribute in the form
        form.dataset.editMealId = mealId;
    };

    // Function to handle [Delete] button click
    const handleDeleteClick = async (mealId) => {
        try {
            // Send DELETE request to remove the item
            const response = await fetch(apiUrl + mealId, {
                method: 'DELETE',
            });

            if (!response.ok) {
                throw new Error(`Failed to delete meal: ${response.statusText}`);
            }

            // Fetch meals after successful deletion
            await loadMeals();
        } catch (error) {
            console.error('Error deleting meal:', error);
        }
    };

    // Function to get meal details by ID (replace this with your actual implementation)
    const getMealDetailsById = (mealId) => {
        // Implement this function to fetch meal details from your data source
        // For example, you might use another fetch request to get details by ID
        // Replace this with your actual implementation
        return {
            food: 'Example Food',
            time: '12:00 PM',
            calories: 500,
        };
    };
});
